require "language_pack/base"

module LanguagePack
  class LanguagePack::Base
    BUILDPACK_VERSION = "v200"
  end
end
