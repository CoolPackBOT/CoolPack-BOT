require "language_pack"

module LanguagePack::Test
end

require "language_pack/test/ruby"
require "language_pack/test/rails2"
